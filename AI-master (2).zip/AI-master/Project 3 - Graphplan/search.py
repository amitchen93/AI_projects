"""
In search.py, you will implement generic search algorithms
"""
import math
import util


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        util.raiseNotDefined()

    def is_goal_state(self, state):
        """
        state: Search state

        Returns True if and only if the state is a valid goal state
        """
        util.raiseNotDefined()

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        util.raiseNotDefined()

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        util.raiseNotDefined()


class State:
    def __init__(self, state, action, accumulated_cost, previous, h_cost = 0, is_goal = False):
        self.state = state
        self.action = action
        self.accumulated_cost = accumulated_cost
        self.previous = previous
        self.h_cost = h_cost
        self._h = None
        self.is_goal = is_goal

    def __lt__(self, other):
        if self.is_goal and not other.is_goal:
            return True
        return self.h_cost < other.h_cost

    def __hash__(self):
        if self._h is None:
            self._h = hash(self.state)
        return self._h

    def __eq__(self, other):
        return self.state == other.state





def depth_first_search(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches
    the goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

	print("Start:", problem.get_start_state().state)
    print("Is the start a goal?", problem.is_goal_state(problem.get_start_state()))
    print("Start's successors:", problem.get_successors(problem.get_start_state()))
    """
    "*** YOUR CODE HERE ***"
    visited = set()
    stack = util.Stack()
    stack.push(State(problem.get_start_state(), None, 0, None))  # push initial state
    actions = list()
    while not stack.isEmpty():
        state = stack.pop()
        state_index = state.state
        if state_index not in visited:
            visited.add(state_index)
            if problem.is_goal_state(state_index):
                # empty the stack upon reaching a goal state
                tmp = state
                while tmp:
                    actions.append(tmp.action)
                    tmp = tmp.previous
                actions = actions[::-1][1:]
                break
            else:
                for successor in problem.get_successors(state_index):
                    if successor[0] not in visited:
                        stack.push(State(successor[0], successor[1], successor[2], state))
    return actions

    # util.raiseNotDefined()


def breadth_first_search(problem):
    """
    Search the shallowest nodes in the search tree first.
    """
    "*** YOUR CODE HERE ***"
    queue = util.Queue()
    queue.push(State(problem.get_start_state(), None, 0, None))
    visited = set()
    actions = list()

    while not queue.isEmpty():
        state = queue.pop()
        state_index = state.state
        if problem.is_goal_state(state_index):
            # empty the stack upon reaching a goal state
            tmp = state
            while tmp:
                actions.append(tmp.action)
                tmp = tmp.previous
            actions = actions[::-1][1:]
            break

        for successor in problem.get_successors(state_index):
            if successor[0] not in visited:
                queue.push(State(successor[0], successor[1], successor[2], state))
                visited.add(successor[0])
    return actions



    # util.raiseNotDefined()




def uniform_cost_search(problem):
    """
    Search the node of least total cost first.
    """
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()
    queue = util.PriorityQueue()
    queue.push(State(problem.get_start_state(), None, 0, None), 0)
    visited = set()
    actions = list()

    while not queue.isEmpty():
        state = queue.pop()
        state_index = state.state
        state_acc_cost = state.accumulated_cost
        if problem.is_goal_state(state_index):
            # empty the stack upon reaching a goal state
            tmp = state
            while tmp:
                actions.append(tmp.action)
                tmp = tmp.previous
            return actions[::-1][1:]
        if state_index not in visited:
            visited.add(state_index)
            for successor in problem.get_successors(state_index):
                if successor[0] not in visited:
                    successor_cost = state_acc_cost + successor[2]
                    queue.push(State(successor[0], successor[1], successor_cost, state), successor_cost)

    return actions


def null_heuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def a_star_search(problem, heuristic=null_heuristic):
    """
    Search the node that has the lowest combined cost and heuristic first.
    """
    "*** YOUR CODE HERE ***"

    queue = util.PriorityQueue()
    start_state = problem.get_start_state()
    queue.push(State(start_state, None, 0, None, heuristic(start_state, problem)), 0)
    visited = set()
    m = math.inf
    actions = []
    push = queue.push
    pop = queue.pop

    goal = problem.is_goal_state
    get_succ = problem.get_successors
    add = visited.add

    while not queue.isEmpty():

        state = pop()
        state_index = state.state
        state_cost = state.accumulated_cost

        if goal(state_index):
            # empty the stack upon reaching a goal state
            actions = []
            tmp = state
            while tmp:
                actions.append(tmp.action)
                tmp = tmp.previous
            return actions[::-1][1:]

        if state not in visited:
            add(state)
            successors = get_succ(state_index)
            for succ, action, price in successors:
                successor_cost = state_cost + price
                heuristic_cost = heuristic(succ, problem)
                estimated_cost = heuristic_cost + successor_cost
                successor_state = State(succ, action, successor_cost, state, heuristic_cost)
                if estimated_cost >= m:
                    continue
                if goal(succ):
                    m = successor_cost
                    successor_state.is_goal = True
                push(successor_state, estimated_cost)
    return None


# Abbreviations
bfs = breadth_first_search
dfs = depth_first_search
astar = a_star_search
ucs = uniform_cost_search
