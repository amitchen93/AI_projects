import sys
from itertools import chain

pairs = "ON({dis1},{dis2})"
empty = "FREE({dis1})"

def create_domain_file(domain_file_name, n_, m_):
    disks = ['d_%s' % i for i in list(range(n_))]  # [d_0,..., d_(n_ - 1)]
    pegs = ['p_%s' % i for i in list(range(m_))]  # [p_0,..., p_(m_ - 1)]
    domain_file = open(domain_file_name, 'w')  # use domain_file.write(str) to write to domain_file
    "*** YOUR CODE HERE ***"
    domain_file.write("Propositions: \n")


    # write propositions
    for disc1 in range(n_):
        domain_file.write(empty.format(dis1=disks[disc1]) + " ") # nothing on top
        for disc2 in range(disc1 + 1, n_):
            domain_file.write(pairs.format(dis1=disks[disc1], dis2=disks[disc2]) + " ")
        for peg in pegs:
            domain_file.write(pairs.format(dis1=disks[disc1], dis2=peg) + " ")
    for peg in pegs:
        domain_file.write(empty.format(dis1=peg) + " ") # nothing on top

    domain_file.write("\nActions:\n")

    # Action = (x, y ,z)
    # x: disc to move
    # y: disc curr position
    # z: disc next position
    for disc1 in range(n_):

        for disc2 in range(disc1 + 1, n_):

            for disc3 in chain(range(disc1 + 1, disc2), range(disc2 + 1, n_)):
                write_action(domain_file, disks[disc1], disks[disc2], disks[disc3])

            for peg in pegs:
                write_action(domain_file, disks[disc1], disks[disc2], peg)

        for peg in range(m_):
            for disc2 in range(disc1 + 1, n_):
                write_action(domain_file, disks[disc1], pegs[peg], disks[disc2])

            for peg2 in range(peg + 1, m_):
                write_action(domain_file, disks[disc1], pegs[peg], pegs[peg2])

    domain_file.close()


def write_action(file, x, y, z):
    # Name
    file.write('Name: M({x},{y},{z})\n'.format(x=x, y=y, z=z))

    # Pre
    file.write('pre: {x} {y} {z}\n'.format(x=empty.format(dis1=x), y=pairs.format(dis1=x, dis2=y), z=empty.format(dis1=z)))

    # Add
    file.write('add: {y} {z}\n'.format(y=empty.format(dis1=y), z=pairs.format(dis1=x, dis2=z)))

    # Delete
    file.write('delete: {y} {z}\n'.format(y=pairs.format(dis1=x, dis2=y), z=empty.format(dis1=z)))



def create_problem_file(problem_file_name_, n_, m_):
    disks = ['d_%s' % i for i in list(range(n_))]  # [d_0,..., d_(n_ - 1)]
    pegs = ['p_%s' % i for i in list(range(m_))]  # [p_0,..., p_(m_ - 1)]
    problem_file = open(problem_file_name_, 'w')  # use problem_file.write(str) to write to problem_file
    "*** YOUR CODE HERE ***"
    problem_file.write("Initial state: {x} ".format(x=empty.format(dis1=disks[0])))
    for peg in pegs[1:]:
        problem_file.write("{x} ".format(x=empty.format(dis1=peg)))
    for disc1 in range(n_ - 1):
        problem_file.write("{x} ".format(x=pairs.format(dis1=disks[disc1], dis2=disks[disc1 + 1])))
    problem_file.write("{x}\n".format(x=pairs.format(dis1=disks[-1], dis2=pegs[0])))

    problem_file.write("Goal state: {x} ".format(x=empty.format(dis1=disks[0])))
    for peg in pegs[:-1]:
        problem_file.write("{x} ".format(x=empty.format(dis1=peg)))
    for disc1 in range(n_ - 1):
        problem_file.write("{x} ".format(x=pairs.format(dis1=disks[disc1], dis2=disks[disc1 + 1])))
    problem_file.write("{x}\n".format(x=pairs.format(dis1=disks[-1], dis2=pegs[-1])))

    problem_file.close()


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print('Usage: hanoi.py n m')
        sys.exit(2)

    n = int(float(sys.argv[1]))  # number of disks
    m = int(float(sys.argv[2]))  # number of pegs

    domain_file_name = 'hanoi_%s_%s_domain.txt' % (n, m)
    problem_file_name = 'hanoi_%s_%s_problem.txt' % (n, m)

    create_domain_file(domain_file_name, n, m)
    create_problem_file(problem_file_name, n, m)
