# todo - dont forget to delete it
import os

epsilons = [0.1 * x for x in range(10)]
learning_rate = [0.1 * x for x in range(10)]

for e in epsilons:
    for l in learning_rate:
        call_str = "python3 gridworld.py -a q -k 50 -n 0 -g BridgeGrid -e {epsilon} -l {learning}".format(epsilon = e, learning = l)
        os.system(call_str)
