# analysis.py
# -----------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

######################
# ANALYSIS QUESTIONS #
######################

# Change these default values to obtain the specified policies through
# value iteration.

def question2():
  """
  This way the agent will only look at the reward due to no noise.
  """
  answerDiscount = 0.9
  answerNoise = 0.0
  return answerDiscount, answerNoise

def question3a():
  """
  We set the reward to a negative number so the agent would have want to gain less steps.
  """
  answerDiscount = 0.9
  answerNoise = 0.2
  answerLivingReward = -3
  return answerDiscount, answerNoise, answerLivingReward
  # If not possible, return 'NOT POSSIBLE'

def question3b():
  """
  We set the reward to 0 because if it was positive the agent would have want to gain more steps, and on the contrary if
  the it was negative it would have risk going through the cliff towards the closest target.
  We lowered the discount so the agent would choose closer reward targets, and set the noise accordingly.
  """
  answerDiscount = 0.15
  answerNoise = 0.1
  answerLivingReward = 0.0
  return answerDiscount, answerNoise, answerLivingReward
  # If not possible, return 'NOT POSSIBLE'

def question3c():
  """
  We set the reward to a negative number so the agent would have want to gain less steps so in this way it would risk
  moving on the cliff. Also like we have seen before setting the noise to 0 will also increase the chance to move on the
  cliff.
  """
  answerDiscount = 0.9
  answerNoise = 0.0
  answerLivingReward = -1
  return answerDiscount, answerNoise, answerLivingReward
  # If not possible, return 'NOT POSSIBLE'

def question3d():
  """
  default settings.
  With noise the agent will avoid moving on the cliff. Also, with 0 reward the agent wouldn't mind taking more steps.
  With the given discount the agent would prefer the more rewarding target.
  """
  answerDiscount = 0.9
  answerNoise = 0.2
  answerLivingReward = 0.0
  return answerDiscount, answerNoise, answerLivingReward
  # If not possible, return 'NOT POSSIBLE'

def question3e():
  """
  With positive reward the agent would prefer taking more steps so it would avoid moving on the cliff.
  With no discount the agent wouldn't care about the reward given in the two targets.
  With 0 nois the agent would avoid falling from the cliff.
  """
  answerDiscount = 0.0
  answerNoise = 0.0
  answerLivingReward = 10.0
  return answerDiscount, answerNoise, answerLivingReward
  # If not possible, return 'NOT POSSIBLE'

def question6():
  """
  We tried fine tuning with all of the combinations of epsilon = learning rate = {0, 0.1, 0.2, ..., 0.9, 1} and for 50
  episodes and for each combination the agent wasn't even close to cross the bridge leaving us with the assumption that
  for this number of episode it will never reach.
  """
  answerEpsilon = None
  answerLearningRate = None
  return 'NOT POSSIBLE'
  # If not possible, return 'NOT POSSIBLE'
  
if __name__ == '__main__':
  print('Answers to analysis questions:')
  import analysis
  for q in [q for q in dir(analysis) if q.startswith('question')]:
    response = getattr(analysis, q)()
    print('Question %s:\t%s' % (q, str(response)))
