import itertools
import math

import numpy as np
import abc
import util
from game import Agent, Action


class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """

    def get_action(self, game_state):
        """
        You do not need to change this method, but you're welcome to.

        get_action chooses among the best options according to the evaluation function.

        get_action takes a game_state and returns some Action.X for some X in the set {UP, DOWN, LEFT, RIGHT, STOP}
        """

        # Collect legal moves and successor states
        legal_moves = game_state.get_agent_legal_actions()

        # Choose one of the best actions
        scores = [self.evaluation_function(game_state, action) for action in legal_moves]
        best_score = max(scores)
        best_indices = [index for index in range(len(scores)) if scores[index] == best_score]
        chosen_index = np.random.choice(best_indices)  # Pick randomly among the best

        "Add more of your code here if you want to"

        return legal_moves[chosen_index]

    def evaluation_function(self, current_game_state, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (GameState.py) and returns a number, where higher numbers are better.

        """

        # Useful information you can extract from a GameState (game_state.py)

        successor_game_state = current_game_state.generate_successor(action=action)
        board = successor_game_state.board
        max_tile = successor_game_state.max_tile
        score = successor_game_state.score

        "*** YOUR CODE HERE ***"
        return better(successor_game_state)



def score_evaluation_function(current_game_state):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return current_game_state.score


class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinmaxAgent, AlphaBetaAgent & ExpectimaxAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evaluation_function='scoreEvaluationFunction', depth=2):
        self.evaluation_function = util.lookup(evaluation_function, globals())
        self.depth = depth

    @abc.abstractmethod
    def get_action(self, game_state):
        return


MAX_INDEX = 0
MIN_INDEX = 1


class MinmaxAgent(MultiAgentSearchAgent):
    def _max_value(self, state, depth):
        actions = state.get_legal_actions(MAX_INDEX)
        if depth <= 0 or len(actions) == 0:
            return self.evaluation_function(state), Action.STOP

        max_val, best_action = -math.inf, Action.STOP
        for action in actions:
            successor = state.generate_successor(MAX_INDEX, action)
            val, _ = self._min_value(successor, depth - 1)
            if max_val < val:
                max_val, best_action = val, action
        return max_val, best_action

    def _min_value(self, state, depth):
        actions = state.get_legal_actions(MIN_INDEX)
        if depth <= 0 or len(actions) == 0:
            return self.evaluation_function(state), Action.STOP

        min_val, best_action = math.inf, Action.STOP
        for action in actions:
            successor = state.generate_successor(MIN_INDEX, action)
            val, _ = self._max_value(successor, depth - 1)
            if min_val > val:
                min_val, best_action = val, action
        return min_val, best_action

    def get_action(self, game_state):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        game_state.get_legal_actions(agent_index):
            Returns a list of legal actions for an agent
            agent_index=0 means our agent, the opponent is agent_index=1

        Action.STOP:
            The stop direction, which is always legal

        game_state.generate_successor(agent_index, action):
            Returns the successor game state after an agent takes an action
        """
        """*** YOUR CODE HERE ***"""
        # util.raiseNotDefined()
        return self._max_value(game_state, 2 * self.depth)[1]


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def _max_value(self, state, depth, alpha, beta):
        actions = state.get_legal_actions(MAX_INDEX)
        if depth <= 0 or len(actions) == 0:
            return self.evaluation_function(state), Action.STOP

        best_action = -math.inf, Action.STOP
        for action in actions:
            if beta <= alpha:
                break
            successor = state.generate_successor(MAX_INDEX, action)
            val, _ = self._min_value(successor, depth - 1, alpha, beta)
            if alpha < val:
                alpha = val
                best_action = action
        return alpha, best_action

    def _min_value(self, state, depth, alpha, beta):
        actions = state.get_legal_actions(MIN_INDEX)
        if depth <= 0 or len(actions) == 0:
            return self.evaluation_function(state), Action.STOP

        best_action = math.inf, Action.STOP
        for action in actions:
            if beta <= alpha:
                break
            successor = state.generate_successor(MIN_INDEX, action)
            val, _ = self._max_value(successor, depth - 1, alpha, beta)
            if beta > val:
                beta = val
                best_action = action
        return beta, best_action

    def get_action(self, game_state):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        """*** YOUR CODE HERE ***"""
        # util.raiseNotDefined()
        return self._max_value(game_state, 2 * self.depth, -math.inf, math.inf)[1]


class ExpectimaxAgent(MultiAgentSearchAgent):
    """
    Your expectimax agent (question 4)
    """

    def _max_value(self, state, depth):
        actions = state.get_legal_actions(MAX_INDEX)
        if depth <= 0 or len(actions) == 0:
            return self.evaluation_function(state), Action.STOP

        max_val, best_action = -math.inf, Action.STOP
        for action in actions:
            successor = state.generate_successor(MAX_INDEX, action)
            val, _ = self._expectimax(successor, depth - 1)
            if max_val < val:
                max_val, best_action = val, action
        return max_val, best_action

    def _expectimax(self, state, depth):
        actions = state.get_legal_actions(MIN_INDEX)
        if depth <= 0 or len(actions) == 0:
            return self.evaluation_function(state), Action.STOP
        score = sum([self._max_value(state.generate_successor(MIN_INDEX, action), depth - 1)[0] for action in actions])
        score /= len(actions)
        return score, actions[np.random.randint(0, len(actions))]

    def get_action(self, game_state):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        The opponent should be modeled as choosing uniformly at random from their
        legal moves.
        """
        """*** YOUR CODE HERE ***"""
        # util.raiseNotDefined()
        return self._max_value(game_state, 2 * self.depth)[1]


def better_evaluation_function(current_game_state):
    """
    Your extreme 2048 evaluation function (question 5).

    DESCRIPTION:
    In our evaluation function we combined three different heuristics and gave each one of them a unique weight.
    The weights were given by trial and error until we got some satisfying results. Furthermore, we set an initial
    score to be the sum of cumsums of the first row and the highets tile, the reason behind that is that according to
    our heurisitics we encourges more ordered board so if the board reached the last row it might be because the game
    is about to end. So better score in the first row at the end of the game will (most of the time) give better score
    overall.

    The first heuristic is the ‘empty’ heuristics which gives a higher score for a board with more empty blocks.
    The motivation behind this heuristic is that the emptier the board is the smaller the chance for getting blocked.

    The second heuristic is the ‘merge’ heuristic.
    This heuristic grade a board by the number of possible merges that it contains so that in the next step there is a
    higher chance to get emptier board and to gain more score by merging blocks.

    The third and last heuristic is the ‘monotonous’ heuristic which gives a negative score for non-monotonous section
    in a row or in a col.
    The idea behind this is that the more organized the row or col is the more predictable our next move will be.
    """
    "*** YOUR CODE HERE ***"
    empty_score = 11.985
    merges_score = 15
    monotonicity_score = 8.451

    max_tile = current_game_state.max_tile

    board = current_game_state.board
    score = sum(np.cumsum(board[0])) + max_tile


    # once on the rows and than on the cols
    for i in range(2):
        for row in range(4):
            in_row = [(x, len(list(y))) for x, y in itertools.groupby(board[row])]
            for x, y in in_row:
                if x != 0 and y > 1:
                    score += (merges_score * y) + (x * ((y // 2) * 2))
                elif x == 0:
                    score += empty_score * y
            left, right = 0, 0

            for j in range(1, 4):
                if board[row][j - 1] > board[row][j]:
                    left += left + 1
                else:
                    right += right + 1
            score -= monotonicity_score * min(left, right)
        board = board.T  # transpose the board

    return score


# Abbreviation
better = better_evaluation_function
