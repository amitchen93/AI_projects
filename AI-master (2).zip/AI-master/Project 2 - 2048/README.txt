313549206
308162502
*****
Comments:
In our evaluation function we combined three different heuristics and gave each one of them a unique weight.
The weights were given by trial and error until we got some satisfying results. Furthermore, we set an initial score to
be the sum of cumsums of the first row and the highets tile, the reason behind that is that according to our heurisitics
we encourges more ordered board so if the board reached the last row it might be because the game is about to end. So
better score in the first row at the end of the game will (most of the time) give better score overall.

The first heuristic is the ‘empty’ heuristics which gives a higher score for a board with more empty blocks.
The motivation behind this heuristic is that the emptier the board is the smaller the chance for getting blocked.

The second heuristic is the ‘merge’ heuristic.
This heuristic grade a board by the number of possible merges that it contains so that in the next step there is a
higher chance to get emptier board and to gain more score by merging blocks.

The third and last heuristic is the ‘monotonous’ heuristic which gives a negative score for non-monotonous section in
a row or in a col. The idea behind this is that the more organized the row or col is the more predictable our next
move will be.

