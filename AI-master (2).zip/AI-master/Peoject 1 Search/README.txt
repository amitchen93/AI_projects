308162502
313549206
*****
Comments:
Files:
        - README - This file
        - search.py - Contains the different algorithms for searching
        - blokus_problems.py - Contains different problems definitions and heuristic to solve them.
