from board import Board, Move
from pieces import Piece
from search import SearchProblem, ucs, bfs, astar
import util
import numpy as np
import math


class BlokusFillProblem(SearchProblem):
    """
    A one-player Blokus game as a search problem.
    This problem is implemented for you. You should NOT change it!
    """

    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0)):
        self.board = Board(board_w, board_h, 1, piece_list, starting_point)
        self.expanded = 0

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def is_goal_state(self, state):
        """
        state: Search state
        Returns True if and only if the state is a valid goal state
        """
        return not any(state.pieces[0])

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        # Note that for the search problem, there is only one player - #0
        self.expanded = self.expanded + 1
        return [(state.do_move(0, move), move, 1) for move in state.get_legal_moves(0)]

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        return len(actions)



#####################################################
# This portion is incomplete.  Time to write code!  #
#####################################################
class BlokusCornersProblem(SearchProblem):
    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0)):
        "*** YOUR CODE HERE ***"
        piece_list.pieces = sorted(piece_list.pieces, key=lambda piece: piece.get_num_tiles())
        self.board = Board(board_w, board_h, 1, piece_list, starting_point)
        self.expanded = 0
        self.empty = self.board.get_position(starting_point[0], starting_point[1])

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def is_goal_state(self, state):
        "*** YOUR CODE HERE ***"
        # util.raiseNotDefined()

        x = state.get_position(0, 0)
        y = state.get_position(0, self.board.board_h - 1)
        z = state.get_position(self.board.board_w - 1, 0)
        w = state.get_position(self.board.board_w - 1, self.board.board_h - 1)

        return self.empty not in [x, y, z, w]

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        # Note that for the search problem, there is only one player - #0
        self.expanded = self.expanded + 1

        return set((state.do_move(0, move), move, move.piece.get_num_tiles()) for move in state.get_legal_moves(0))



    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        "*** YOUR CODE HERE ***"
        # util.raiseNotDefined()

        total_tiles = 0
        for move in actions:
            total_tiles += move.piece.get_num_tiles()
        return total_tiles

    def get_aproximation(self, state, num):
        pieces = np.array(state.piece_list.pieces)[state.pieces[0]]
        pieces = [piece.get_num_tiles() for piece in pieces[: num]]
        return sum(pieces)


def distance(x, y):
    """
    euclidean distance
    """
    return ((x[1] - y[1]) ** 2 + (x[0] - y[0]) ** 2) ** 0.5


def blokus_corners_heuristic(state, problem):
    """
    Your heuristic for the BlokusCornersProblem goes here.

    This heuristic must be consistent to ensure correctness.  First, try to come up
    with an admissible heuristic; almost all admissible heuristics will be consistent
    as well.

    If using A* ever finds a solution that is worse uniform cost search finds,
    your heuristic is *not* consistent, and probably not admissible!  On the other hand,
    inadmissible or inconsistent heuristics may find optimal solutions, so be careful.
    """
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()
    corners = list()
    w, h = (state.board_w - 1, state.board_h - 1)

    if problem.is_goal_state(state):
        return 0

    else:
        if state.get_position(0, 0) == problem.empty:
            corners.append((0, 0))
        if state.get_position(0, h) == problem.empty:
            corners.append((0, h))
        if state.get_position(w, 0) == problem.empty:
            corners.append((w, 0))
        if state.get_position(w, h) == problem.empty:
            corners.append((w, h))

    for c in corners:
        x, y = c
        if x == 0:
            if state.state[y, x+1] == 0:
                return math.inf
        else:
            if state.state[y, x - 1] == 0:
                return math.inf
        if y == 0:
            if state.state[y + 1, x] == 0:
                return math.inf
        else:
            if state.state[y - 1, x] == 0:
                return math.inf

    m = math.inf
    indexes = np.argwhere(state.connected & state._legal[0])
    if len(indexes) == 0:
        return m
    for _, x, y in indexes:
        for i, uncovered in enumerate(corners):
            uy, ux = uncovered
            if x == ux or y == uy:
                mid_dis = 1 + ((x - ux) ** 2 + (y - uy) ** 2) ** 0.5
            elif abs(x - ux) == 1 or abs(y - uy) == 1:
                mid_dis = util.manhattanDistance((y, x), uncovered)
            else:
                mid_dis = ((x - ux) ** 2 + (y - uy) ** 2) ** 0.5

            m = min(m, mid_dis)

    tmp = np.ceil(m) + problem.get_aproximation(state, len(corners) - 1)
    if tmp <= (w + 1) * (h + 1) - state.scores[0]:
        return tmp
    return np.ceil(m) + len(corners) - 1


class BlokusCoverProblem(SearchProblem):
    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0), targets=[(0, 0)]):
        piece_list.pieces = sorted(piece_list.pieces, key=lambda piece: piece.get_num_tiles())
        self.targets = targets.copy()
        self.expanded = 0
        "*** YOUR CODE HERE ***"
        self.board = Board(board_w, board_h, 1, piece_list, starting_point)
        self.empty = self.board.get_position(starting_point[0], starting_point[1])

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def is_goal_state(self, state):
        "*** YOUR CODE HERE ***"
        # util.raiseNotDefined()
        for target in self.targets:
            if state.get_position(target[1], target[0]) == self.empty:
                return False
        return True

    def get_successors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        # Note that for the search problem, there is only one player - #0
        self.expanded = self.expanded + 1
        return [(state.do_move(0, move), move, move.piece.get_num_tiles()) for move in state.get_legal_moves(0)]

    def get_cost_of_actions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        "*** YOUR CODE HERE ***"
        # util.raiseNotDefined()
        total_tiles = 0
        for move in actions:
            total_tiles += move.piece.get_num_tiles()
        return total_tiles


def blokus_cover_heuristic(state, problem):
    "*** YOUR CODE HERE ***"
    # util.raiseNotDefined()
    targets = set()

    if problem.is_goal_state(state):
        return 0

    for target in problem.targets:
        if state.get_position(target[1], target[0]) == problem.empty:
            targets.add(target)

    indexes = np.argwhere(state.connected & state._legal[0])
    distances = math.inf
    for _, x, y in indexes:
        for uncovered in targets:
            ux, uy = uncovered
            if x == ux or y == uy:
                mid_dis = 1 + ((x - ux) ** 2 + (y - uy) ** 2) ** 0.5
            elif abs(x - ux) == 1 or abs(y - uy) == 1:
                mid_dis = util.manhattanDistance((x, y), uncovered)
            else:
                mid_dis = ((x - ux) ** 2 + (y - uy) ** 2) ** 0.5
            distances = min(distances, mid_dis)

    return np.ceil(distances) + len(targets) - 1


class State:
    def __init__(self, state, action, accumulated_cost, previous, h_cost = 0):
        self.state = state
        self.action = action
        self.accumulated_cost = accumulated_cost
        self.previous = previous
        self.h_cost = h_cost
        self._h = None

    def __lt__(self, other):
        return self.h_cost < other.h_cost

    def __hash__(self):
        if not self._h:
            self._h = hash(self.state)
        return self._h

    def __eq__(self, other):
        return self.state == other.state


class ClosestLocationSearch:
    """
    In this problem you have to cover all given positions on the board,
    but the objective is speed, not optimality.
    """

    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0), targets=(0, 0)):
        self.expanded = 0
        self.targets = targets.copy()
        "*** YOUR CODE HERE ***"
        self.board = Board(board_w, board_h, 1, piece_list, starting_point)
        self.empty = self.board.get_position(starting_point[0], starting_point[1])
        self.start = starting_point
        self.w, self.h = board_w, board_h


    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def a_star_search(self, problem, heuristic):
        """
        Search the node that has the lowest combined cost and heuristic first.
        """
        "*** YOUR CODE HERE ***"

        queue = util.PriorityQueue()
        queue.push(State(problem.get_start_state(), None, 0, None, 0), 0)
        visited = set()
        m = math.inf
        push = queue.push
        pop = queue.pop

        goal = problem.is_goal_state
        get_succ = problem.get_successors
        add = visited.add

        while not queue.isEmpty():

            state = pop()
            state_index = state.state
            state_cost = state.accumulated_cost

            if goal(state_index):
                # empty the stack upon reaching a goal state
                actions = []
                tmp = state
                while tmp:
                    actions.append(tmp.action)
                    tmp = tmp.previous
                return actions[::-1][1:], state_index

            if state not in visited:
                add(state)
                successors = get_succ(state_index)
                for succ, action, price in successors:
                    successor_cost = state_cost + price
                    heuristic_cost = heuristic(succ, problem) * 100
                    estimated_cost = heuristic_cost + successor_cost
                    successor_state = State(succ, action, successor_cost, state, heuristic_cost)
                    if estimated_cost >= m:
                        add(successor_state)
                        continue
                    if goal(succ):
                        m = successor_cost
                    push(successor_state, estimated_cost)

    def solve(self):
        """
        This method should return a sequence of actions that covers all target locations on the board.
        This time we trade optimality for speed.
        Therefore, your agent should try and cover one target location at a time. Each time, aiming for the closest uncovered location.
        You may define helpful functions as you wish.

        Probably a good way to start, would be something like this --

        current_state = self.board.__copy__()
        backtrace = []

        while ....

            actions = set of actions that covers the closets uncovered target location
            add actions to backtrace

        return backtrace
        """
        "*** YOUR CODE HERE ***"
        targets = util.PriorityQueue()
        actions = []
        state = self.board.__copy__()
        for t in self.targets:
            targets.push(t, distance(self.start, t))

        while not targets.isEmpty():
            target = targets.pop()
            problem = BlokusCoverProblem(self.w, self.h, self.board.piece_list, self.start, [target])
            problem.board = state
            _actions, state = self.a_star_search(problem, blokus_cover_heuristic)
            self.expanded += problem.expanded
            actions += _actions
        return actions



class MiniContestSearch:
    """
    Implement your contest entry here
    """

    def __init__(self, board_w, board_h, piece_list, starting_point=(0, 0), targets=(0, 0)):
        self.targets = targets.copy()
        "*** YOUR CODE HERE ***"

    def get_start_state(self):
        """
        Returns the start state for the search problem
        """
        return self.board

    def solve(self):
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

